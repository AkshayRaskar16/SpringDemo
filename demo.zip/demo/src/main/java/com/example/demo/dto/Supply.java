package com.example.demo.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Supply {
	private String productId;
	private Double availQty;
	
	public Supply() {
		
	};

	public Supply(String productId, Double availQty) {
		super();
		this.productId = productId;
		this.availQty = availQty;
	}
}
