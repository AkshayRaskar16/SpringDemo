package com.example.demo.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Order {
	//String orderId, String productId,Double qty
	private String orderId;
	private String productId;
	private Double availQty;
	
	public Order() {
	}

	public Order(String orderId, String productId, Double availQty) {
		super();
		this.productId = productId;
		this.orderId = orderId;
		this.availQty = availQty;
		
	}
}