package com.example.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.example.demo.dto.Availability;
import com.example.demo.dto.Demand;
import com.example.demo.dto.Inventory;
import com.example.demo.dto.Order;
import com.example.demo.dto.ProdAvailabilityReq;
import com.example.demo.dto.Shipment;
import com.example.demo.dto.Supply;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DemoService { 
	//problem 1
	/*
	 * public Inventory getOrderDetails(Date orderDate) throws ParseException {
	 * List<Order> orderList = Stream.of(new Order("Order1", "Prod1",
	 * 2.0)).toList();
	 * 
	 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd"); List<Shipment>
	 * shipmentList = Stream.of(new Shipment("Order1", "Ship1", "Prod1",
	 * sdf.parse("2021-03-28"))).toList(); String resp ="0"; return resp; }
	 */
	
	//problem2
	public Object getAvailability(ProdAvailabilityReq payload) throws Exception {

		List<Supply> supplyList = Stream.of(new Supply("Product1", 10.0),
				new Supply("Product2", 5.0)).toList();
		List<Demand> demandList = Stream.of(new Demand("Product1", 2.0),
				new Demand("Product2", 5.0)).toList();
		
		ExecutorService executor = Executors.newFixedThreadPool(5);
		List<Callable<Object>> callableList = new ArrayList<>();

		List<Future<Object>> results = null;
		
		try {
			//callableList.add(() -> getAvailability(payload.getProductId()));

			//double demandQ = supplyList.getProductId();
			//double supplyQ = getSupply(payload.getProductId());;
			String product = payload.getProductId();

		}  finally {
			executor.shutdown();
		}
		
		return null;
	}
}