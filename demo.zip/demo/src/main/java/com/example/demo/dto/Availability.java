package com.example.demo.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Availability {

	private String storeNo;
	private String productId;
	private java.util.Date date;
	private Double availQty;

	public Availability() {

	}

	public Availability(String storeNo, String productId, Date date, Double availQty) {
		super();
		
	}

}
