package com.example.demo.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Shipment {
	//String orderId, String shipmentId, String productId ,Date shipmentDate,Double qty
	private String orderId;
	private String shipmentId;
	private String productId;
	private java.util.Date date;
	private Double availQty;
	
	public Shipment() {
	}

	public Shipment(String orderId, String shipmentId, String productId, Date date) {
		super();
		this.productId = productId;
		this.orderId = orderId;
		this.shipmentId = shipmentId;
		this.date = date;
		
	}
}