package com.example.demo.controller;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Inventory;
import com.example.demo.dto.ProdAvailabilityReq;
import com.example.demo.service.DemoService;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class DemoController {

	@Autowired
	private DemoService demoService;

	//problem 1
	@PostMapping("getOrderDetails")
	public Object getOrderDetails(@RequestBody Inventory payload) throws Exception {
		return 0;
	}
	
	//problem 2
	@PostMapping("getAvailability")
	public Object getAvailability(@RequestBody ProdAvailabilityReq payload) throws Exception {
		
		return demoService.getAvailability(payload);
	}
}