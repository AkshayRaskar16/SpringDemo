package com.example.demo.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Demand {
	private String productId;
	private Double availQty;
	
	public Demand() {
		
	};

	public Demand(String productId, Double availQty) {
		super();
		this.productId = productId;
		this.availQty = availQty;
	}

}
